#include <gtk/gtk.h>


void
on_button3_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_appliquer_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_quitter_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajout_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_quitter_affi_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour_aj_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_affich_row_activated                (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_supp_clicked                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Retour0_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_gestionvol_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_gestionexcurtion_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Return3_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Valider0_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);
