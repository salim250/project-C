int verifier_connextion(char Pseudo[],char Password[]);
