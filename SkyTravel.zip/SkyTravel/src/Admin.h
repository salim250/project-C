void afficher_Agents(GtkWidget *liste);
void afficher_Searched_Agents(GtkWidget *liste ,char *searh_Pseudo,char *searh_Prenom,char*searh_Nom,char*searh_Email,char*searh_Tel);
