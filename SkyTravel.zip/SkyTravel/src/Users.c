#include<string.h>
#include <stdio.h>
#include <stdlib.h>
#include"Users.h"

#include "support.h"
enum
{	
	c_PSEUDO,
	c_NOM,
	c_PRENOM,
	c_EMAIL,
	c_ADRESSE,
	c_TEL,
	c_COLUMNS
};
/*********Get info from formulaire**************/
User Get_User_info(GtkWidget *objet_graphique)
{

User user;
GtkWidget *input;
//Get PSeudo
input = lookup_widget(objet_graphique, "entry_Pseudo_Signup") ;
strcpy(user.Pseudo,gtk_entry_get_text(GTK_ENTRY(input)));
//Get Password
input = lookup_widget(objet_graphique, "entry_Password_Signup") ;
strcpy(user.Password,gtk_entry_get_text(GTK_ENTRY(input)));
//Get Nom
input = lookup_widget(objet_graphique, "entry_Nom_Signup") ;
strcpy(user.nom,gtk_entry_get_text(GTK_ENTRY(input)));
//Get Prénom
input = lookup_widget(objet_graphique, "entry_Prenom_Signup") ;
strcpy(user.prenom,gtk_entry_get_text(GTK_ENTRY(input)));
//Get Email
input = lookup_widget(objet_graphique, "entry_Email_Signup") ;
strcpy(user.Email,gtk_entry_get_text(GTK_ENTRY(input)));
g_print("\n Getting birthday");
//Get Birth_Day


input = lookup_widget(objet_graphique, "Jour") ;
user.Birth_day.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input));
input = lookup_widget(objet_graphique, "Mois") ;
user.Birth_day.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input));
input = lookup_widget(objet_graphique, "Annee") ;
user.Birth_day.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input));
/*
input = lookup_widget(objet_graphique, "Jour") ;
strcpy(user.Birth_day,gtk_entry_get_text(GTK_ENTRY(input)));
strcat(user.Birth_day,"/");
input = lookup_widget(objet_graphique, "Mois") ;
strcat(user.Birth_day,gtk_entry_get_text(GTK_ENTRY(input)));
strcat(user.Birth_day,"/");
input = lookup_widget(objet_graphique, "Annee") ;
strcat(user.Birth_day,gtk_entry_get_text(GTK_ENTRY(input)));*/
//Get phone number
input = lookup_widget(objet_graphique, "entry_Tel_Signup") ;
strcpy(user.Tel,gtk_entry_get_text(GTK_ENTRY(input)));
//Get Adress
input = lookup_widget(objet_graphique, "entry_Adresse_Signup") ;
strcpy(user.Adresse,gtk_entry_get_text(GTK_ENTRY(input)));

return user;
}
/*********Add a user**************/
void add_user(User user)
{
strcpy(user.Type,"User");

FILE *f;
f=fopen("/home/bouzayen/Desktop/Skytravel/Users.bin","ab");
if(f!=NULL)
	{
	fwrite(&user,sizeof(user),1,f);
	}
fclose(f);
/*********Check_pseudo**************/
}
int Check_pseudo_user_signup(char Pseudo[])
{
struct User A;
int pseudo_check=1;
FILE *f;
f=fopen("/home/bouzayen/Desktop/Skytravel/Users.bin","rb");
if(f !=NULL) 
	{
	while(!feof(f)&&pseudo_check==1)
		{
		fread(&A,1,sizeof(A),f);
		if(!(strcmp(A.Pseudo,Pseudo)))pseudo_check=0;
		}
	fclose(f);
	}

return  pseudo_check;
}
/*********Check Password**************/
int Veif_Password(User X)
{
int password_ok=0;
int Maj=0;
int Min=0;
int Num=0;int i=0; long ascii = 0;
for(i=0;i<20;i++)
	{ascii = X.Password[i];
	if(ascii>=64&&ascii<=90)Maj++;
	if(ascii>=97&&ascii<=122)Min++;
	if(ascii>=48&&ascii<=57)Num++;
	}
if(Maj>0&&Min>0&&Num>0&&strlen(X.Password)>7)password_ok=1;
return password_ok;
}
/**********************chek email**************************/
int check_useremail(char email[])
{int i;int at=0;
g_print("\nChecking eamail\n");
for(i=0;i<=50&&email[i]!='\0';i++)
	{
	if(email[i]=='@'){at++;}
	}

if(at==1)return 1;
else return 0;
}

/*********Supp User***************/
void dell_user(char *Pseudo)
{
struct User A;
FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("/home/bouzayen/Desktop/Skytravel/Userstmp.bin","wb");
fclose(new);
/******copy data from old to new *******/
old=fopen("/home/bouzayen/Desktop/Skytravel/Users.bin","rb");
new=fopen("/home/bouzayen/Desktop/Skytravel/Userstmp.bin","ab");
/**************************/
int i=0;
while(!(feof(old)))
	{i++;
	fread(&A,1,sizeof(A),old);
	}
fclose(old);
old=fopen("/home/bouzayen/Desktop/Skytravel/Users.bin","rb");
/******************************/
int j=0;
while(j<i-1)
	{j++;
	fread(&A,1,sizeof(A),old);
	g_print("Psuedo  : %s\n",A.Pseudo);
	if(strcmp(A.Pseudo,Pseudo))
		{	
		fwrite(&A,sizeof(A),1,new);
		}
	}
fclose(new);
fclose(old);
remove("/home/bouzayen/Desktop/Skytravel/Users.bin");//nfas5ou il fichier li9dim
rename("/home/bouzayen/Desktop/Skytravel/Userstmp.bin","/home/bouzayen/Desktop/Skytravel/Users.bin");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
/*****Na3mlo Actualiser lil liste **************/

}

/********************Afficher all Users same as Agents ************************/
void afficher_All_Users(GtkWidget *liste)
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

  store=gtk_tree_view_get_model(liste);
  if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Pseudo", renderer, "text",c_PSEUDO, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Nom", renderer, "text",c_NOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Prenom", renderer, "text",c_PRENOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Email", renderer, "text",c_EMAIL, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Telephone", renderer, "text",c_TEL, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	


	
	}
	store=gtk_list_store_new (c_COLUMNS, G_TYPE_STRING,  		G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, 		G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

struct User X;
FILE *f;
/******************************************************/
f=fopen("/home/bouzayen/Desktop/Skytravel/Users.bin","rb");
int i=0;
while(!(feof(f)))
{
fread(&X,1,sizeof(X),f);
i++;
}
fclose(f);
g_print("\n i = %d",i);
/**********************************************************/
f=fopen("/home/bouzayen/Desktop/Skytravel/Users.bin","rb");
if(f!=NULL)
	if(f!=NULL)
	{int j=0;
	
	while(j<i-1)
		{
		
		fread(&X,1,sizeof(X),f);
		if(!(strcmp(X.Type,"User")))
		{g_print("\n J = %d %s",j,X.Type);
		gtk_list_store_append (store, &iter);
		gtk_list_store_set (store, &iter, c_PSEUDO, X.Pseudo, c_NOM, X.nom, c_PRENOM, X.prenom, c_EMAIL, X.Email,c_ADRESSE,X.Adresse,c_TEL,X.Tel, -1);
		} 
		j++;
		}//while(j<i-1)
	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
        g_object_unref (store);
	}//if(f!=NULL)

}

/********************Afficher just searched User kima agents ************************/
void afficher_Searched_Users(GtkWidget *liste ,char *searh_Pseudo,char *searh_Prenom,char*searh_Nom,char*searh_Email,char*searh_Tel)
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;
	
  store=gtk_tree_view_get_model(liste);

  if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Pseudo", renderer, "text",c_PSEUDO, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Nom", renderer, "text",c_NOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Prenom", renderer, "text",c_PRENOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Email", renderer, "text",c_EMAIL, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Telephone", renderer, "text",c_TEL, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	


	
	}//if(store==NULL)
        
	store=gtk_list_store_new (c_COLUMNS, G_TYPE_STRING,  		G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, 		G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

struct User X;
FILE *f;
/******************************************************/
f=fopen("/home/bouzayen/Desktop/Skytravel/Users.bin","rb");
int i=0;
while(!(feof(f)))
{
fread(&X,1,sizeof(X),f);
i++;
}
fclose(f);
//g_print("\n i = %d",i);
/**********************************************************/

int j=0;
if(!(strcmp(searh_Pseudo,""))&&!(strcmp(searh_Prenom,""))&&!(strcmp(searh_Nom,""))&&!(strcmp(searh_Email,""))&&!(strcmp(searh_Tel,"")))
{
f=fopen("/home/bouzayen/Desktop/Skytravel/Users.bin","rb");
if(f!=NULL)
	{g_print("\nFerghin");
	j=0;
	while(j<i-1)
		{
		//g_print("\n J =%d",j);
		fread(&X,1,sizeof(X),f);
		if(!(strcmp(X.Type,"User")))
		{
		gtk_list_store_append (store, &iter);
		gtk_list_store_set (store, &iter, c_PSEUDO, X.Pseudo, c_NOM, X.nom, c_PRENOM, X.prenom, c_EMAIL, X.Email,c_ADRESSE,X.Adresse,c_TEL,X.Tel, -1);
		} 
		j++;
		}//while(j<i-1)
	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
        g_object_unref (store);
	}//if(f!=NULL)
}//if loula
else
{//*searh_Pseudo,*searh_Prenom,*searh_Nom,*searh_Email,*searh_Tel;

	f=fopen("/home/bouzayen/Desktop/Skytravel/Users.bin","rb");
if(f!=NULL)
	{
	j=0;
	while(j<i-1)
		{	g_print("\n J =%d",j);
		fread(&X,1,sizeof(X),f);
		if(!(strcmp(X.Type,"User")))
		{if(!(strcmp(X.Pseudo,searh_Pseudo))||!(strcmp(X.prenom,searh_Prenom))||!(strcmp(X.nom,searh_Nom))||!(strcmp(X.Email,searh_Email))||!(strcmp(X.Tel,searh_Tel)))
		{
		gtk_list_store_append (store, &iter);
		gtk_list_store_set (store, &iter, c_PSEUDO, X.Pseudo, c_NOM, X.nom, c_PRENOM, X.prenom, c_EMAIL, X.Email,c_ADRESSE,X.Adresse,c_TEL,X.Tel, -1);
		}}//if serach
		 j++;
		}//while(j<i-1)
	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
        g_object_unref (store);
}//if(f!=NULL)
	}//else
}//void 

void Set_User_modified_info(GtkWidget *objet_graphique,User user)
{
g_print("\n In Set user Info");
GtkWidget *input;

input = lookup_widget(objet_graphique, "entry_pseudo_edit_user") ;

gtk_entry_set_text(GTK_ENTRY(input),user.Pseudo);

input = lookup_widget(objet_graphique, "entry_nom_edit_user") ;
gtk_entry_set_text(GTK_ENTRY(input),user.nom);


input = lookup_widget(objet_graphique, "entry_prenom_edit_user") ;
gtk_entry_set_text(GTK_ENTRY(input),user.prenom);

input = lookup_widget(objet_graphique, "entry_email_edit_user") ;

gtk_entry_set_text(GTK_ENTRY(input),user.Email);


g_print("\n setting spin buttons");

input = lookup_widget(objet_graphique, "entry_jour_edit_user") ;
gtk_spin_button_set_value (input,
                           user.Birth_day.jour);


input = lookup_widget(objet_graphique, "entry_mois_edit_user") ;
gtk_spin_button_set_value (input,
                           user.Birth_day.mois);


input = lookup_widget(objet_graphique, "entry_anne_edit_user") ;
gtk_spin_button_set_value (input,
                          user.Birth_day.anne);


input = lookup_widget(objet_graphique, "entry_tel_edit_user") ;
gtk_entry_set_text(GTK_ENTRY(input),user.Tel);


input = lookup_widget(objet_graphique, "entry_adresse_edit_user") ;
gtk_entry_set_text(GTK_ENTRY(input),user.Adresse);


}
User Get_User_modified_info(GtkWidget *objet_graphique)
{

User user;
GtkWidget *input;
//Get PSeudo
input = lookup_widget(objet_graphique, "entry_pseudo_edit_user") ;
strcpy(user.Pseudo,gtk_entry_get_text(GTK_ENTRY(input)));
//Get Nom
input = lookup_widget(objet_graphique, "entry_nom_edit_user") ;
strcpy(user.nom,gtk_entry_get_text(GTK_ENTRY(input)));
//Get Prénom
input = lookup_widget(objet_graphique, "entry_prenom_edit_user") ;
strcpy(user.prenom,gtk_entry_get_text(GTK_ENTRY(input)));
//Get Email
input = lookup_widget(objet_graphique, "entry_email_edit_user") ;
strcpy(user.Email,gtk_entry_get_text(GTK_ENTRY(input)));
//Get Birth_Day
input = lookup_widget(objet_graphique, "entry_jour_edit_user") ;
user.Birth_day.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input));
input = lookup_widget(objet_graphique, "entry_mois_edit_user") ;
user.Birth_day.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input));
input = lookup_widget(objet_graphique, "entry_annee_edit_user") ;
user.Birth_day.anne=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input));
//Get phone number
input = lookup_widget(objet_graphique, "entry_tel_edit_user") ;
strcpy(user.Tel,gtk_entry_get_text(GTK_ENTRY(input)));
//Get Adress
input = lookup_widget(objet_graphique, "entry_adresse_edit_user") ;
strcpy(user.Adresse,gtk_entry_get_text(GTK_ENTRY(input)));

return user;
}
