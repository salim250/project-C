#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
//#include <main.c>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"Users.h"
#include"Verif_login.h"
#include"Conversion_needed.h"
#include"Admin.h"
#include"Agent.h"
#include"Catalogues.h"
#include "hotel.h"

GtkWidget *Agents_Gesture_interfaces;GtkWidget *Users_Gesture_interfaces,*Catalogue_Gesture_interfaces;
struct User who_is_logged,Selected_Agent,Selected_User;
struct Hotel Selected_Hotel;
//add_pixmap_directory ("/home/bouzayen/Desktop/Skytraveltodo/SkyTravel/pixmaps");

void
on_buttonSignup_clicked                (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Signin_up_interface,* Interface_Acceuill;
Interface_Acceuill =lookup_widget(objet_graphique,"MainMenu");
Signin_up_interface=create_Signup_interface ();
gtk_widget_show(Signin_up_interface);

/*GtkWidget *filechooserdialog1;
filechooserdialog1=create_filechooserdialog1();
gtk_widget_show(filechooserdialog1);*/
Users_Gesture_interfaces=lookup_widget(objet_graphique,"Users_Gesture_interface");
}

void
on_buttonForgot_Password_clicked       (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{

}

void
on_Acount_Settings_clicked             (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
}

void
on_button_Catalogues_Gesture_clicked   (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Catalogue_Gesture_interface,*Admin_interface;
GtkWidget *Viewport_Catalogue;

Admin_interface=lookup_widget(objet_graphique,"Admin_interface");
gtk_widget_destroy(Admin_interface);
Catalogue_Gesture_interface=create_Catalogue_Gesture_interface();
gtk_widget_show(Catalogue_Gesture_interface);
Viewport_Catalogue=lookup_widget(Catalogue_Gesture_interface,"viewport_Catalogue_Gesture");
afficher_catalogue_Gesture(Viewport_Catalogue,Catalogue_Gesture_interface);

}


void
on_button_statistics_Gesture_clicked   (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{

}

void
on_button_Agents_Gesture_clicked       (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Admin_interface,*Agents_Gesture_interface;
GtkWidget *treeAgents;

Admin_interface=lookup_widget(objet_graphique,"Admin_interface");
gtk_widget_destroy(Admin_interface);
Agents_Gesture_interface=create_Agents_Gesture_interface();
gtk_widget_show(Agents_Gesture_interface);
treeAgents=lookup_widget(Agents_Gesture_interface,"treeview_Agents");
afficher_Agents(treeAgents);
}

void
on_button_Users_Gesture_clicked        (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Admin_interface,*Users_Gesture_interface;
GtkWidget *treeUSERS;

Admin_interface=lookup_widget(objet_graphique,"Admin_interface");
gtk_widget_destroy(Admin_interface);
Users_Gesture_interface=create_Users_Gesture_interface();
gtk_widget_show(Users_Gesture_interface);
treeUSERS=lookup_widget(Users_Gesture_interface,"treeview_Users");
afficher_All_Users(treeUSERS);


}


void
on_button_Claim_Gesture_clicked        (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{

}

void
on_Search_Agents_Gesture_clicked (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{

char searh_Pseudo[50],searh_Prenom[50],searh_Nom[50],searh_Email[50],
searh_Tel[50];
GtkWidget *input;

input = lookup_widget(objet_graphique,"entry_Nom_Gestion_Agents");
strcpy(searh_Nom,gtk_entry_get_text(GTK_ENTRY(input)));
input = lookup_widget(objet_graphique,"entry_Prenom_Gestion_Agents");
strcpy(searh_Prenom,gtk_entry_get_text(GTK_ENTRY(input)));
input = lookup_widget(objet_graphique,"entry_Pseudo_Gestion_Agents");
strcpy(searh_Pseudo,gtk_entry_get_text(GTK_ENTRY(input)));
input = lookup_widget(objet_graphique,"entry_Email_Gestion_Agents");
strcpy(searh_Email,gtk_entry_get_text(GTK_ENTRY(input)));
input = lookup_widget(objet_graphique,"entry_Tel_Gestion_Agents");
strcpy(searh_Tel,gtk_entry_get_text(GTK_ENTRY(input)));


GtkWidget *tree_searcher_Agents,*Agents_Gesture_interface;
Agents_Gesture_interface=lookup_widget(objet_graphique,"Agents_Gesture_interface");

tree_searcher_Agents=lookup_widget(Agents_Gesture_interface,"treeview_Agents");

afficher_Searched_Agents(tree_searcher_Agents ,searh_Pseudo,searh_Prenom,
searh_Nom,searh_Email,searh_Tel);

gtk_widget_show(tree_searcher_Agents);
}

void
on_buttonSignin_clicked                (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{GtkWidget     *MainMenu;
MainMenu=lookup_widget(objet_graphique,"MainMenu");
gtk_widget_destroy(MainMenu);
GtkWidget *Login_inteface;
//Login_inteface =lookup_widget(objet_graphique,"MainMenu");
Login_inteface=create_Login_inteface ();
gtk_widget_show(Login_inteface);

}

void
on_button_Save_User_Signup_clicked     (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
struct User X;
X=Get_User_info(objet_graphique);
/*________________Verfication de Pseudo________________________*/
int pseudo_check=1;
pseudo_check=Check_pseudo_user_signup((char*)X.Pseudo);
/*________________Verfication de Mot de passe ______________*/

int password_ok=0;
password_ok=Veif_Password(X);

/*________Verfication de confirmation de Mot de passe ______________*/
GtkWidget *input;
int password_confirm=0;
input = lookup_widget(objet_graphique, "entry_Confirm_Password_Signup") ;
password_confirm=!(strcmp(X.Password,gtk_entry_get_text(GTK_ENTRY(input))));
/*________Verfication De L'email ______________*/
char email[20];int email_check=1;
email_check=check_useremail(X.Email);

/*******************************************************************/
if(pseudo_check==0)
	{
	GtkWidget *dialog_Pseudo_Not_Okey;
	dialog_Pseudo_Not_Okey=create_dialog_Pseudo_Not_Okey();
	gtk_widget_show(dialog_Pseudo_Not_Okey);
	}
if(password_ok==0)
	{
	GtkWidget *dialog_Password_error;
	dialog_Password_error=create_dialog_Password_error();
	gtk_widget_show(dialog_Password_error);
	}
if(password_confirm==0)
	{
	GtkWidget *dialog_Password_dont_match;
	dialog_Password_dont_match=create_dialog_Password_dont_match();
	gtk_widget_show(dialog_Password_dont_match);
	}
if(email_check==0)
	{
	GtkWidget *dialog_email_error;
	dialog_email_error=create_dialog_email_error();
	gtk_widget_show(dialog_email_error);
	}
if(pseudo_check==1&&password_ok==1&&password_confirm==1&&email_check==1)
	{add_user(X);
	GtkWidget *Signup_Interface;
	Signup_Interface=lookup_widget(objet_graphique,"Signup_interface");
	gtk_widget_destroy(Signup_Interface);
	}

if(Users_Gesture_interfaces!=NULL)
{
GtkWidget *treeUSERS;
treeUSERS=lookup_widget(Users_Gesture_interfaces,"treeview_Users");
afficher_All_Users(treeUSERS);
}

/*
GtkWidget *Admin_interface,*Users_Gesture_interface;
GtkWidget *treeUSERS;
Admin_interface=lookup_widget(objet_graphique,"Admin_interface");
gtk_widget_destroy(Admin_interface);
Users_Gesture_interface=create_Users_Gesture_interface();
gtk_widget_show(Users_Gesture_interface);
treeUSERS=lookup_widget(Users_Gesture_interface,"treeview_Users");
afficher_All_Users(treeUSERS);
treeAgents=lookup_widget(Agents_Gesture_interfaces,"treeview_Agents");
afficher_Agents(treeAgents);
//gtk_widget_show(Agents_Gesture_interface);
gtk_widget_show(treeAgents);
g_print("clicked\n");*/
}


void
on_entry_Pseudo_Signup_editing_done    (GtkCellEditable *celleditable,
                                        gpointer         user_data,GtkWidget     *objet_graphique)
{


}

void
on_closebutton1_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}

void
on_entry_Confirm_Password_Signup_editing_done
                                        (GtkCellEditable *celleditable,
                                        gpointer         user_data,GtkWidget *objet_graphique)
{

}

void
on_entry_Password_Signup_editing_done  (GtkCellEditable *celleditable,
                                        gpointer         user_data,GtkWidget *objet_graphique)
{
}

void
on_buttonLogin_check_clicked           (GtkWidget *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Login_inteface;
Login_inteface=lookup_widget(objet_graphique,"Login_inteface");
char Pseudo[20];
char Password[20];
int i;
int num=0;
GtkWidget *input;
input = lookup_widget(objet_graphique, "entryPseudo") ;
strcpy(Pseudo,gtk_entry_get_text(GTK_ENTRY(input)));
input = lookup_widget(objet_graphique, "entryPassword") ;
strcpy(Password,gtk_entry_get_text(GTK_ENTRY(input)));
num=verifier_connextion(Pseudo,Password);

if(num!=-1)
	{
	g_print(" %d Pass %s Ps %s Wana connect ",num,Password,Pseudo);
	FILE *f;
	f=fopen("/home/bouzayen/Desktop/Skytravel/Users.bin","rb");
	if(f!=NULL)
		for(i=0;i<=num;i++)
		{
	
		fread(&who_is_logged,1,sizeof(who_is_logged),f);

		}
	fclose(f);
	g_print("\n\nlist jusqua i %d !0 %d Psuedo %s Pass : %s Type : %s",i,num,who_is_logged.Pseudo,who_is_logged.Password,who_is_logged.Type);

	}
		if(!(strcmp("Admin",who_is_logged.Type)))
			{
			GtkWidget *Admin_interface,*out;	
			Admin_interface=create_Admin_interface();
			
			char loged_as[30];			
			strcpy(loged_as,"Admin :  ");
			strcat(loged_as,(char*)who_is_logged.nom);
			strcat(loged_as," ");
			strcat(loged_as,(char*)who_is_logged.prenom);

		out=lookup_widget(Admin_interface,"Whos_loged");
		gtk_label_set_text(GTK_LABEL(out),loged_as);
			gtk_widget_show (Admin_interface);
		     	gtk_widget_destroy(Login_inteface);
			
			}
		if(!(strcmp("Agent",who_is_logged.Type)))
			{	
			GtkWidget *Agents_inteface,*out;
			Agents_inteface =create_Agents_inteface();
			char loged_as[30];			
			strcpy(loged_as,"Agent :  ");
			strcat(loged_as,(char*)who_is_logged.nom);
			strcat(loged_as," ");
			strcat(loged_as,(char*)who_is_logged.prenom);
			gtk_widget_show (Agents_inteface);
			gtk_widget_destroy(Login_inteface);
		out=lookup_widget(Agents_inteface,"label114");
		gtk_label_set_text(GTK_LABEL(out),loged_as);
			}
		if(!(strcmp("User",who_is_logged.Type)))
			{
			/*Agents_inteface =create_Agents_inteface();
			gtk_widget_show (Agents_inteface);
			gtk_widget_destroy(Login_inteface);*/
			}
}

void
on_closePseudo_not_okey_clicked        (GtkWidget       *object,
                                        gpointer         user_data)
{

GtkWidget *Pseudo_Not_Okey;

Pseudo_Not_Okey=lookup_widget(object,"dialog_Pseudo_Not_Okey");

gtk_widget_destroy(Pseudo_Not_Okey);
}


void
on_okb_password_dont_match_clicked     (GtkWidget       *object,
                                        gpointer         user_data)
{
GtkWidget *password_dont_match;

password_dont_match=lookup_widget(object,"dialog_Password_dont_match");

gtk_widget_destroy(password_dont_match);

}


void
on_ok_Password_error_clicked           (GtkWidget       *object,
                                        gpointer         user_data)
{
GtkWidget *password_error;

password_error=lookup_widget(object,"dialog_Password_error");

gtk_widget_destroy(password_error);
}
void
on_Retour_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{}

void
on_Return_gAgents_Admin_clicked        (GtkWidget *  objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Admin_interface,*Agents_Gesture_interface,*Users_Gesture_interface,*Catalogue_Gesture;
GtkWidget *out;	
Admin_interface=Admin_interface=create_Admin_interface();			
char loged_as[30];			
strcpy(loged_as,"Admin :  ");
strcat(loged_as,(char*)who_is_logged.nom);
strcat(loged_as," ");
strcat(loged_as,(char*)who_is_logged.prenom);								  out=lookup_widget(Admin_interface,"Whos_loged");
gtk_label_set_text(GTK_LABEL(out),loged_as);
	
Agents_Gesture_interface=lookup_widget(objet_graphique,"gestion_prestation");
gtk_widget_destroy (Agents_Gesture_interface);
	Agents_Gesture_interface=lookup_widget(objet_graphique,"Agents_Gesture_interface");
	gtk_widget_destroy (Agents_Gesture_interface);
	Users_Gesture_interface=lookup_widget(objet_graphique,"Users_Gesture_interface");
	gtk_widget_destroy (Users_Gesture_interface);
	Catalogue_Gesture=lookup_widget(objet_graphique,"Catalogue_Gesture_interface");
	gtk_widget_destroy (Catalogue_Gesture);
	Catalogue_Gesture=lookup_widget(objet_graphique,"Gestion_des_Prestations");
	gtk_widget_destroy (Catalogue_Gesture);
	gtk_widget_show (Admin_interface);
}


void
on_button_Add_Agent_clicked            (GtkWidget *  objet_graphique,
                                        gpointer         user_data)
{

GtkWidget*Add_Agent_interface;
	Agents_Gesture_interfaces=lookup_widget(objet_graphique,"Agents_Gesture_interface");
	//gtk_widget_hide (Agents_Gesture_interfaces);
Add_Agent_interface=create_Add_Agent_interface();
gtk_widget_show(Add_Agent_interface);
}


void
on_button_Save_Agent_clicked           (GtkWidget *  objet_graphique,
                                        gpointer         user_data)
{
struct User X;
X=Get_Agent_info(objet_graphique);

/*________________Verfication de Pseudo________________________*/
int pseudo_check=1;
pseudo_check=Check_pseudo_Agent_signup((char*)X.Pseudo);
/*________________Verfication de Mot de passe ______________*/
int password_ok=0;
password_ok=Veif_Password(X);
/*________Verfication de confirmation de Mot de passe ______________*/
GtkWidget *input;
int password_confirm=0;
input = lookup_widget(objet_graphique, "Add_Agent_Confirm_Password") ;
password_confirm=!(strcmp(X.Password,gtk_entry_get_text(GTK_ENTRY(input))));

if(pseudo_check==0)
	{
	GtkWidget *dialog_Pseudo_Not_Okey;
	dialog_Pseudo_Not_Okey=create_dialog_Pseudo_Not_Okey();
	gtk_widget_show(dialog_Pseudo_Not_Okey);
	}
if(password_ok==0)
	{
	GtkWidget *dialog_Password_error;
	dialog_Password_error=create_dialog_Password_error();
	gtk_widget_show(dialog_Password_error);
	}
if(password_confirm==0)
	{
	GtkWidget *dialog_Password_dont_match;
	dialog_Password_dont_match=create_dialog_Password_dont_match();
	gtk_widget_show(dialog_Password_dont_match);
	}
if(pseudo_check==1&&password_ok==1&&password_confirm==1)
	{add_Agent(X);
g_print("\n Agents birth date %d ",X.Birth_day.jour);
	GtkWidget *Add_Agent_Interface;
	Add_Agent_Interface=lookup_widget(objet_graphique,"Add_Agent_interface");
	gtk_widget_destroy(Add_Agent_Interface);
}

GtkWidget *treeAgents,*Agents_Gesture_interface;
//Agents_Gesture_interface=create_Agents_Gesture_interface();


treeAgents=lookup_widget(Agents_Gesture_interfaces,"treeview_Agents");
afficher_Agents(treeAgents);
//gtk_widget_show(Agents_Gesture_interface);
gtk_widget_show(treeAgents);
g_print("clicked\n");
}


void
on_treeview_Agents_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;//gchar kima char *
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))//
  { 
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);//namlo cpy lil continue te3 collone loula (0) fi str_data 
  }
strcpy(Selected_Agent.Pseudo,str_data);//Selected_agent structure Globale 
FILE *f;
f=fopen("/home/bouzayen/Desktop/Skytravel/Users.bin","rb");
if(f!=NULL)
	{
	struct User A;
	while(!(feof(f)))
		{
		fread(&A,1,sizeof(User),f);
		if(strcmp(Selected_Agent.Pseudo,A.Pseudo)==0)Selected_Agent=A;
		}	
	}
}





void
on_Dell_Agent_clicked                  (GtkWidget *  objet_graphique,
                                        gpointer         user_data)
{
dell_user((char *)Selected_Agent.Pseudo);
/*****Na3mlo Actualiser lil liste **************/
GtkWidget *treeAgents,*Agents_Gesture_interface;
Agents_Gesture_interface=lookup_widget(objet_graphique,"Agents_Gesture_interface");
treeAgents=lookup_widget(Agents_Gesture_interface,"treeview_Agents");

afficher_Agents(treeAgents);
gtk_widget_show(treeAgents);
}

void
on_Disconect_Admin_Interface_clicked   (GtkWidget *  objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *MainMenu,*Admin_Interface;
Admin_Interface=lookup_widget(objet_graphique,"Admin_interface");
gtk_widget_destroy(Admin_Interface);
MainMenu=create_MainMenu();
GtkWidget *viewport_Catalogue,*Table_show_Catalogues;
viewport_Catalogue=lookup_widget(MainMenu,"viewport_Catalogue");
afficher_catalogue(viewport_Catalogue);
gtk_widget_show(MainMenu);
}




void
on_Consulter_Catalogues_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
g_print("\n Called Consulter Catalogues %s",user_data);
}




void
on_buttonDelete_User_clicked           (GtkWidget *  objet_graphique,
                                        gpointer         user_data)
{
dell_user((char *)Selected_User.Pseudo);
/*****Na3mlo Actualiser lil liste **************/
GtkWidget *treeUsers,*Agents_Gesture_interface;
Agents_Gesture_interface=lookup_widget(objet_graphique,"Users_Gesture_interface");
treeUsers=lookup_widget(Agents_Gesture_interface,"treeview_Users");

afficher_All_Users(treeUsers);
gtk_widget_show(treeUsers);
}




void
on_Return_toAgents_Gesture_clicked     (GtkWidget *  objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Agents_Gesture_interface,*Add_Agent_interface;
GtkWidget *treeAgents;

Add_Agent_interface=lookup_widget(objet_graphique,"Add_Agent_interface");
gtk_widget_destroy(Add_Agent_interface);

Agents_Gesture_interface=create_Agents_Gesture_interface();
gtk_widget_show(Agents_Gesture_interface);

treeAgents=lookup_widget(Agents_Gesture_interface,"treeview_Agents");
afficher_Agents(treeAgents);
}


void
on_buttonSearch_Users_Gesture_clicked  (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
char searh_Pseudo[50],searh_Prenom[50],searh_Nom[50],searh_Email[50],
searh_Tel[50];
GtkWidget *input;
input = lookup_widget(objet_graphique,"entry_Nom_Gestion_Users");
strcpy(searh_Nom,gtk_entry_get_text(GTK_ENTRY(input)));
input = lookup_widget(objet_graphique,"entry_Prenom_Gestion_Users");
strcpy(searh_Prenom,gtk_entry_get_text(GTK_ENTRY(input)));
input = lookup_widget(objet_graphique,"entry_Pseudo_Gestion_Users");
strcpy(searh_Pseudo,gtk_entry_get_text(GTK_ENTRY(input)));
input = lookup_widget(objet_graphique,"entry_Email_Gestion_Users");
strcpy(searh_Email,gtk_entry_get_text(GTK_ENTRY(input)));
input = lookup_widget(objet_graphique,"entry_Tel_Gestion_Users");
strcpy(searh_Tel,gtk_entry_get_text(GTK_ENTRY(input)));
GtkWidget *tree_searcher_Users,*Users_Gesture_interface;
Users_Gesture_interface=lookup_widget(objet_graphique,"Users_Gesture_interface");
tree_searcher_Users=lookup_widget(Users_Gesture_interface,"treeview_Users");
afficher_Searched_Users(tree_searcher_Users ,searh_Pseudo,searh_Prenom,
searh_Nom,searh_Email,searh_Tel);

gtk_widget_show(tree_searcher_Users);
}


void
on_treeview_Users_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  }
strcpy(Selected_User.Pseudo,str_data);
FILE *f;
f=fopen("/home/bouzayen/Desktop/Skytravel/Users.bin","rb");
if(f!=NULL)
	{
	struct User A;
	while(!(feof(f)))
		{
		fread(&A,1,sizeof(User),f);
		if(strcmp(Selected_User.Pseudo,A.Pseudo)==0)Selected_User=A;
		}	
	}
}


void
on_button_Prest_Gesture_clicked        (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget     *Gestion_des_Prestations,*Admin_interface;
Gestion_des_Prestations=create_gestion_prestation();
gtk_widget_show(Gestion_des_Prestations);
Admin_interface=lookup_widget(objet_graphique,"Admin_interface");
gtk_widget_destroy(Admin_interface);
}


void
on_buttonSearch_Catalogue_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_filechooser_selection_changed       (GtkFileChooser  *filechooser,
                                        gpointer         user_data)
{
g_print("\n%s",gtk_file_chooser_get_uri (filechooser));
}
void
on_Edit_Catalogues_clicked(GtkWidget     *objet_graphique,
					gpointer         user_data)
{

}
void
on_Delete_Catalogues_clicked(GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
g_print("\n%s \n",user_data);
supp_catalogue_Hotel(user_data);
}

void
on_okbutton_Email_Error_clicked        (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *dialog;
dialog=lookup_widget(button,"dialog_email_error");
gtk_widget_destroy(dialog);
}


void
on_button_Sace_Edit_Agent_clicked      (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{struct User Modified_Agent;
 Modified_Agent=Get_Agent_modified_info(objet_graphique);

dell_user((char *)Selected_Agent.Pseudo);

/*________________Verfication de Pseudo_ et eamil_______________________*/
int pseudo_check=1,email_check=1;
pseudo_check=Check_pseudo_Agent_signup((char*)Modified_Agent.Pseudo);
email_check=check_useremail((char*)Modified_Agent.Email);
if(pseudo_check==0)
	{
	GtkWidget *dialog_Pseudo_Not_Okey;
	dialog_Pseudo_Not_Okey=create_dialog_Pseudo_Not_Okey();
	gtk_widget_show(dialog_Pseudo_Not_Okey);
	}
if(email_check==0)
	{
	GtkWidget *dialog_email_error;
	dialog_email_error=create_dialog_email_error();
	gtk_widget_show(dialog_email_error);
	}
if(pseudo_check==1&&email_check==1)
	{add_Agent(Modified_Agent);
	GtkWidget *Edit_Agent_interface;
	Edit_Agent_interface=lookup_widget(objet_graphique,"Edit_Agent_interface");
	gtk_widget_destroy(Edit_Agent_interface);

	}

/*****Na3mlo Actualiser lil liste **************/
GtkWidget *treeAgents,*Agents_Gesture_interface;
Agents_Gesture_interface=lookup_widget(objet_graphique,"Agents_Gesture_interface");
treeAgents=lookup_widget(Agents_Gesture_interfaces,"treeview_Agents");
afficher_Agents(treeAgents);
gtk_widget_show(treeAgents);
}


void
on_button_Agent_Editer_clicked         (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget     *Agents_Gesture_interface,*Edit_Agent_interface;
Edit_Agent_interface=create_Edit_Agent_interface();
gtk_widget_show(Edit_Agent_interface);
Agents_Gesture_interfaces=lookup_widget(objet_graphique,"Agents_Gesture_interface");

g_print("\n Calling Set agents Info");
Set_Agent_modified_info(Edit_Agent_interface,Selected_Agent);

}


void
on_gestion_hotel_clicked               (GtkWidget *  objet_graphique,
                                        gpointer         user_data)
{
GtkWidget     *Gestion_des_Prestations,*gestion__hotels,*list;
gestion__hotels=create_gestion__hotels();
gtk_widget_show(gestion__hotels);
Gestion_des_Prestations=lookup_widget(objet_graphique,"gestion_prestation");
gtk_widget_destroy(Gestion_des_Prestations);
list=lookup_widget(gestion__hotels,"treeview_Hotel_Gestion_Hotel");

afficher_hotel(list);
}


void
on_gestion_voitures_clicked            (GtkWidget *  objet_graphique,
                                        gpointer         user_data)
{

GtkWidget     *Gestion_des_Prestations,*Gestion_voitures ,*list;
Gestion_voitures=create_Gestion_voitures ();
gtk_widget_show(Gestion_voitures);
g_print("sqdsqdsqdqdqs");
Gestion_des_Prestations=lookup_widget(objet_graphique,"gestion_prestation");
gtk_widget_destroy(Gestion_des_Prestations);
list=lookup_widget(Gestion_voitures,"treeview3");

afficher_voiture(list);

}


void
on_Gestion__vols_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Gestion__excursions_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}



void
on_retour_to_gest_prestation_clicked   (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{GtkWidget     *gestion__hotels,*gestion_prestation;
gestion_prestation=create_gestion_prestation();
gestion__hotels=lookup_widget(objet_graphique,"gestion__hotels");
gtk_widget_destroy(gestion__hotels);
gtk_widget_show(gestion_prestation);
}


void
on_recherche_hotel_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Ajout_hotel_clicked                 (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget     *gestion__hotels,*ajout_hotel;
ajout_hotel=create_ajout_hotel();
gtk_widget_show(ajout_hotel);
gestion__hotels=lookup_widget(objet_graphique,"gestion__hotels");
gtk_widget_destroy(gestion__hotels);
}


void
on_Modifier_hotel_clicked              (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget     *gestion__hotels,*modifier_hotel;
modifier_hotel=create_modifier_hotel();
gtk_widget_show(modifier_hotel);
gestion__hotels=lookup_widget(objet_graphique,"gestion__hotels");
gtk_widget_destroy(gestion__hotels);
set_hotel_info(modifier_hotel,Selected_Hotel);
}


void
on_supprimer_hotel_clicked             (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{GtkWidget*list,*gestion__hotels;
supp_hotel(Selected_Hotel);
gestion__hotels=lookup_widget(objet_graphique,"gestion__hotels");
list=lookup_widget(gestion__hotels,"treeview_Hotel_Gestion_Hotel");
afficher_hotel(list);

}


void
on_recherche_voiture_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ajout_voiture_clicked               (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget     *gestion_voiture,*ajout_voiture;
ajout_voiture=create_ajout_voitures();
gtk_widget_show(ajout_voiture);
gestion_voiture=lookup_widget(objet_graphique,"Gestion_voitures");
gtk_widget_destroy(gestion_voiture);
}





void
on_supprimer_voiture_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Valider_hotel_clicked               (GtkWidget *objet_graphique,
                                        gpointer         user_data)
{
struct Hotel H;
H=get_hotel_info(objet_graphique);
save_hotel(H);
GtkWidget     *gestion__hotels,*ajout_hotel,*list;
gestion__hotels=create_gestion__hotels();
gtk_widget_show(gestion__hotels);
ajout_hotel=lookup_widget(objet_graphique,"ajout_hotel");
gtk_widget_destroy(ajout_hotel);
list=lookup_widget(gestion__hotels,"treeview_Hotel_Gestion_Hotel");
afficher_hotel(list);
}


void
on_return_ajout_to_gest_hotel_clicked  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget     *gestion__hotels,*ajout_hotel,*list;
gestion__hotels=create_gestion__hotels();
gtk_widget_show(gestion__hotels);
ajout_hotel=lookup_widget(objet_graphique,"ajout_hotel");
gtk_widget_destroy(ajout_hotel);
list=lookup_widget(gestion__hotels,"treeview_Hotel_Gestion_Hotel");
afficher_hotel(list);
}


void
on_return_ajout_hotel_to_gest_hotel_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_valider_voiture_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_valider_modif_hotel_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_return_modif_hotel_to_gest_hotel_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget     *gestion__hotels,*modifier_hotel,*list;
gestion__hotels=create_gestion__hotels();
gtk_widget_show(gestion__hotels);
modifier_hotel=lookup_widget(objet_graphique,"modifier_hotel");
gtk_widget_destroy(modifier_hotel);
list=lookup_widget(gestion__hotels,"treeview_Hotel_Gestion_Hotel");
afficher_hotel(list);
}


void
on_valider_amodif_voiture_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_return_modif_voiture_to_gest_voiture_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{

}



void
on_return_gest_voiture_to_gest_prest_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{

}





void
on_modifier_voiture_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}






void
on_treeview_Hotel_Gestion_Hotel_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data,*str_data2,*str_data3;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 1, &str_data2, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 4, &str_data3, -1);
  }
strcpy(Selected_Hotel.Nom,str_data);
strcpy(Selected_Hotel.Lieu,str_data2);
strcpy(Selected_Hotel.Tel,str_data3);
struct Hotel H;
FILE *f;
f=fopen("Hotel.bin","rb");
if(f!=NULL);
{g_print("\nFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF\n");
while(!(feof(f)))	

	{
	fread(&H,1,sizeof(Hotel),f);
	if((strcmp(H.Nom,Selected_Hotel.Nom)!=0)&&(strcmp(H.Tel,Selected_Hotel.Tel)!=0)&&(strcmp(H.Lieu,Selected_Hotel.Lieu))!=0)
	{
	g_print("\nFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF\n");
	Selected_Hotel=H;
	}
	}
fclose(f);
}
}

void
on_buttonEdit_User_clicked             (GtkWidget *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget    *Edit_User_interface;
Edit_User_interface=create_Edit_User_interface();
gtk_widget_show(Edit_User_interface);
Users_Gesture_interfaces=lookup_widget(objet_graphique,"Users_Gesture_interface");

g_print("\n Calling Set agents Info");
Set_User_modified_info(Edit_User_interface,Selected_User);
}

void
on_button_Save_Edit_User_clicked       (GtkWidget *objet_graphique,
                                        gpointer         user_data)
{
struct User Modified_User;
 Modified_User=Get_User_modified_info(objet_graphique);

dell_user((char *)Selected_User.Pseudo);

/*________________Verfication de Pseudo_ et eamil_______________________*/
int pseudo_check=1,email_check=1;
pseudo_check=Check_pseudo_Agent_signup((char*)Modified_User.Pseudo);
email_check=check_useremail((char*)Modified_User.Email);
if(pseudo_check==0)
	{
	GtkWidget *dialog_Pseudo_Not_Okey;
	dialog_Pseudo_Not_Okey=create_dialog_Pseudo_Not_Okey();
	gtk_widget_show(dialog_Pseudo_Not_Okey);
	}
if(email_check==0)
	{
	GtkWidget *dialog_email_error;
	dialog_email_error=create_dialog_email_error();
	gtk_widget_show(dialog_email_error);
	}
if(pseudo_check==1&&email_check==1)
	{add_user(Modified_User);
	GtkWidget *Edit_User_interface;
	Edit_User_interface=lookup_widget(objet_graphique,"Edit_User_interface");
	gtk_widget_destroy(Edit_User_interface);

	}
g_print("actual");
/*****Na3mlo Actualiser lil liste **************/
GtkWidget *treeAgents;
treeAgents=lookup_widget(Users_Gesture_interfaces,"treeview_Users");
afficher_All_Users(treeAgents);
gtk_widget_show(treeAgents);
}




void
on_button_add_catala_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_add_catala_hotel_clicked     (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{struct Catalogue_Hotel C;
C=Get_Catalogue_info(objet_graphique);
int R;
R=C.reduction;
R=((100-R));
strcpy(C.Lieu,Selected_Hotel.Lieu);strcpy(C.Nom,Selected_Hotel.Nom);
C.Prix_ch_simple_1pers=(int*)((R*Selected_Hotel.Prix_ch_simple_1pers)/100);
C.Prix_ch_double_1pers=(int*)((R*Selected_Hotel.Prix_ch_double_1pers)/100);
C.Prix_ch_double_2pers=(int*)((R*Selected_Hotel.Prix_ch_double_2pers)/100);
C.Prix_ch_Triple_1pers=(int*)((R*Selected_Hotel.Prix_ch_Triple_1pers)/100);
C.Prix_ch_Triple_2pers=(int*)((R*Selected_Hotel.Prix_ch_Triple_2pers)/100);
C.Prix_ch_Triple_3pers=(int*)((R*Selected_Hotel.Prix_ch_Triple_3pers)/100);
C.Prix_sweat_1pers=(int*)(R*Selected_Hotel.Prix_sweat_1pers);
C.Prix_sweat_2pers=(int*)(R*Selected_Hotel.Prix_sweat_2pers);
C.Prix_sweat_3pers=(int*)(R*Selected_Hotel.Prix_sweat_3pers);
Save_Catalogue_Hotel(C);
g_print("Strcut\n %d \n %s \n %s \n %s \n %s \n",C.Prix_ch_simple_1pers,C.Lieu, C.Title,C.Image_path,C.Nom);
GtkWidget *Viewport_Catalogue;
Viewport_Catalogue=lookup_widget(Catalogue_Gesture_interfaces,"viewport_Catalogue_Gesture");
afficher_catalogue_Gesture(Viewport_Catalogue,Catalogue_Gesture_interfaces);
}
/*
int Prix_ch_simple_1pers;
int Prix_ch_double_1pers;
int Prix_ch_double_2pers;
int Prix_ch_Triple_1pers;
int Prix_ch_Triple_2pers;
int Prix_ch_Triple_3pers;
int Prix_sweat_1pers;
int Prix_sweat_2pers;
int Prix_sweat_3pers;
*/

void
on_button_Add_Catalogue_Gesture_clicked
                                        (GtkWidget *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget* Add_Catalogue_Hotel,*tree ;
Add_Catalogue_Hotel=create_Add_Catalogue_Hotel();
gtk_widget_show(Add_Catalogue_Hotel);
Catalogue_Gesture_interfaces=lookup_widget(objet_graphique,"Catalogue_Gesture_interface");
tree=lookup_widget(Add_Catalogue_Hotel,"treeview_Hotel_add_cat");
afficher_hotel(tree);
/*GtkWidget     *Add_Catalogue_Hotel,*Gestion_Cat;treeview_Hotel_add_cat
Add_Catalogue_Hotel=create_Add_Catalogue_Hotel();
gtk_widget_show(Add_Catalogue_Hotel);
Gestion_Cat=lookup_widget(objet_graphique,"Add_Catalogue_Hotel");
gtk_widget_destroy(Gestion_Cat);*/
}


void
on_Valider_modif_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}

