#include <gtk/gtk.h>

struct Date
{
int mois;
int jour;
int anne;
};

typedef struct Date Date;


struct User
{	char nom[20];
	char prenom[20];
	char Pseudo[50];
	char Password[20];
	char Email[50];
	Date Birth_day;
	char Tel[20];
	char Adresse[70];
	char Type[20];
};
typedef struct User User;


User Get_User_info(GtkWidget *objet_graphique);
void add_user(User user);
int Veif_Password(User X);
void dell_user(char *Pseudo);
void afficher_All_Users(GtkWidget *liste);
void afficher_Searched_Users(GtkWidget *liste ,char *searh_Pseudo,char *searh_Prenom,char*searh_Nom,char*searh_Email,char*searh_Tel);
int Check_pseudo_user_signup(char Pseudo[]);
int check_useremail(char email[]);
void Set_User_modified_info(GtkWidget *objet_graphique,User user);
User Get_User_modified_info(GtkWidget *objet_graphique);
