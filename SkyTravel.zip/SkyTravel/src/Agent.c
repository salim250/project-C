#include<stdlib.h>
#include<stdio.h>
#include <gtk/gtk.h>
#include <string.h>
#include"Users.h"

#include "support.h"

User Get_Agent_info(GtkWidget *objet_graphique)
{

User agent;
GtkWidget *input;
//Get PSeudo
input = lookup_widget(objet_graphique, "Add_Agent_Pseudo") ;
strcpy(agent.Pseudo,gtk_entry_get_text(GTK_ENTRY(input)));
//Get Password
input = lookup_widget(objet_graphique, "Add_Agent_Password") ;
strcpy(agent.Password,gtk_entry_get_text(GTK_ENTRY(input)));
//Get Nom
input = lookup_widget(objet_graphique, "Add_Agent_Nom") ;
strcpy(agent.nom,gtk_entry_get_text(GTK_ENTRY(input)));
//Get Prénom
input = lookup_widget(objet_graphique, "Add_Agent_Prenom") ;
strcpy(agent.prenom,gtk_entry_get_text(GTK_ENTRY(input)));
//Get Email
input = lookup_widget(objet_graphique, "Add_Agent_Email") ;
strcpy(agent.Email,gtk_entry_get_text(GTK_ENTRY(input)));
//Get Birth_Day

input = lookup_widget(objet_graphique, "Add_Agent_Jour") ;
agent.Birth_day.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input));
input = lookup_widget(objet_graphique, "Add_Agent_Mois") ;
agent.Birth_day.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input));
input = lookup_widget(objet_graphique, "Add_Agent_Annee") ;
agent.Birth_day.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input));
//Get phone number
input = lookup_widget(objet_graphique, "Add_Agent_Tel") ;
strcpy(agent.Tel,gtk_entry_get_text(GTK_ENTRY(input)));
//Get Adress
input = lookup_widget(objet_graphique, "Add_Agent_Adresse") ;
strcpy(agent.Adresse,gtk_entry_get_text(GTK_ENTRY(input)));

return agent;
}
void add_Agent(User Agent)
{
strcpy(Agent.Type,"Agent");

FILE *f;
f=fopen("/home/bouzayen/Desktop/Skytravel/Users.bin","ab");
if(f!=NULL)
	{
	fwrite(&Agent,sizeof(Agent),1,f);
	}
fclose(f);

}
int Check_pseudo_Agent_signup(char Pseudo[])
{
struct User A;
int pseudo_check=1;
FILE *f;
f=fopen("/home/bouzayen/Desktop/Skytravel/Users.bin","rb");
if(f !=NULL) 
	{
	while(!feof(f)&&pseudo_check==1)
		{
		fread(&A,1,sizeof(A),f);
		if(!(strcmp(A.Pseudo,Pseudo)))pseudo_check=0;
		}
	fclose(f);
	}

return  pseudo_check;
}
User Get_Agent_modified_info(GtkWidget *objet_graphique)
{

User agent;
GtkWidget *input;
//Get PSeudo
input = lookup_widget(objet_graphique, "entry_pseudo_edit_agent") ;
strcpy(agent.Pseudo,gtk_entry_get_text(GTK_ENTRY(input)));
//Get Nom
input = lookup_widget(objet_graphique, "entry_nom_edit_agent") ;
strcpy(agent.nom,gtk_entry_get_text(GTK_ENTRY(input)));
//Get Prénom
input = lookup_widget(objet_graphique, "entry_prenom_edit_agent") ;
strcpy(agent.prenom,gtk_entry_get_text(GTK_ENTRY(input)));
//Get Email
input = lookup_widget(objet_graphique, "entry_email_edit_agent") ;
strcpy(agent.Email,gtk_entry_get_text(GTK_ENTRY(input)));
//Get Birth_Day
input = lookup_widget(objet_graphique, "entry_jour_edit_agent") ;
agent.Birth_day.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input));
input = lookup_widget(objet_graphique, "entry_mois_edit_agent") ;
agent.Birth_day.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input));
input = lookup_widget(objet_graphique, "entry_annee_edit_agent") ;
agent.Birth_day.anne=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input));
//Get phone number
input = lookup_widget(objet_graphique, "entry_tel_edit_agent") ;
strcpy(agent.Tel,gtk_entry_get_text(GTK_ENTRY(input)));
//Get Adress
input = lookup_widget(objet_graphique, "entry_email_edit_agent") ;
strcpy(agent.Adresse,gtk_entry_get_text(GTK_ENTRY(input)));

return agent;
}
void Set_Agent_modified_info(GtkWidget *objet_graphique,User agent)
{
g_print("\n In Set agents Info");
GtkWidget *input;
//Get PSeudo
input = lookup_widget(objet_graphique, "entry_pseudo_edit_agent") ;

gtk_entry_set_text(GTK_ENTRY(input),agent.Pseudo);
//Get Nom
input = lookup_widget(objet_graphique, "entry_nom_edit_agent") ;
gtk_entry_set_text(GTK_ENTRY(input),agent.nom);

//Get Prénom
input = lookup_widget(objet_graphique, "entry_prenom_edit_agent") ;
gtk_entry_set_text(GTK_ENTRY(input),agent.prenom);
//Get Email
input = lookup_widget(objet_graphique, "entry_email_edit_agent") ;

gtk_entry_set_text(GTK_ENTRY(input),agent.Email);

//Get Birth_Day
g_print("\n setting spin buttons");

input = lookup_widget(objet_graphique, "entry_jour_edit_agent") ;
gtk_spin_button_set_value (input,
                           agent.Birth_day.jour);


input = lookup_widget(objet_graphique, "entry_mois_edit_agent") ;
gtk_spin_button_set_value (input,
                           agent.Birth_day.mois);


input = lookup_widget(objet_graphique, "entry_annee_edit_agent") ;
gtk_spin_button_set_value (input,
                           agent.Birth_day.anne);

//Get phone number
input = lookup_widget(objet_graphique, "entry_tel_edit_agent") ;
gtk_entry_set_text(GTK_ENTRY(input),agent.Tel);

//Get Adress
input = lookup_widget(objet_graphique, "entry_adresse_edit_agent") ;
gtk_entry_set_text(GTK_ENTRY(input),agent.Adresse);


}
