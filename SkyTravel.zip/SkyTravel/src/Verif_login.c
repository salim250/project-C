#include"Verif_login.h"
#include<string.h>
#include <stdio.h>
#include <stdlib.h>
#include"Users.h"
int verifier_connextion(char Pseudo[],char Password[])
{

struct User A;
int pseudo_found=0;
int password_found=0;
int num;
FILE *f;
f=fopen("/home/bouzayen/Desktop/Skytravel/Users.bin","rb");
if(f !=NULL) {

num=-1;
while
(!feof(f)&&pseudo_found==0&&password_found==0)
{

fread(&A,1,sizeof(A),f);
num++;
g_print("\n %s    %s",A.Pseudo ,A.Password);
if(!(strcmp(A.Pseudo,Pseudo)))
	{
	if(!(strcmp(A.Password,Password)))
		{password_found=1;pseudo_found=1;}
	}


}
fclose(f);
}
if(pseudo_found==1&&password_found==1)
return num;
else return -1;
}
