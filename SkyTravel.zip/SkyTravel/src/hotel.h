struct Hotel
{
char Nom[20];
char Lieu[20];
int Prix_ch_simple_1pers;
int Prix_ch_double_1pers;
int Prix_ch_double_2pers;
int Prix_ch_Triple_1pers;
int Prix_ch_Triple_2pers;
int Prix_ch_Triple_3pers;
int Prix_sweat_1pers;
int Prix_sweat_2pers;
int Prix_sweat_3pers;
char Categorie[20];
char Tel[20];
char reduction[20];

};
typedef struct Hotel Hotel;
Hotel get_hotel_info(GtkWidget *objet_graphique);
void save_hotel(Hotel H);
void afficher_hotel(GtkWidget *liste);
void supp_hotel(Hotel Selected_Hotel);
void set_hotel_info(GtkWidget *objet_graphique,Hotel hotel);
