User Get_Agent_info(GtkWidget *objet_graphique);
void add_Agent(User Agent);
int Check_pseudo_Agent_signup(char Pseudo[]);
User Get_Agent_modified_info(GtkWidget *objet_graphique);
void Set_Agent_modified_info(GtkWidget *objet_graphique,User agent);
