#include <gtk/gtk.h>



void
on_buttonSignup_clicked                (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_buttonForgot_Password_clicked       (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_Acount_Settings_clicked             (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_button_Catalogues_Gesture_clicked   (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_button_statistics_Gesture_clicked   (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_button_Agents_Gesture_clicked       (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_button_Users_Gesture_clicked        (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_button_Claim_Gesture_clicked        (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_Search_Agents_Gesture_clicked  (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_buttonSignin_clicked                (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_button_Save_User_Signup_clicked     (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_entry_Pseudo_Signup_editing_done    (GtkCellEditable *celleditable,
                                        gpointer         user_data,GtkWidget     *objet_graphique);

void
on_closebutton1_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_entry_Confirm_Password_Signup_editing_done
                                        (GtkCellEditable *celleditable,
                                        gpointer         user_data,GtkWidget *objet_graphique);

void
on_entry_Password_Signup_editing_done  (GtkCellEditable *celleditable,
                                        gpointer         user_data,GtkWidget *objet_graphique);

void
on_buttonLogin_check_clicked           (GtkWidget *objet_graphique,
                                        gpointer         user_data);

void
on_closePseudo_not_okey_clicked        (GtkWidget       *object,
                                        gpointer         user_data);

void
on_okb_password_dont_match_clicked     (GtkWidget       *object,
                                        gpointer         user_data);

void
on_ok_Password_error_clicked           (GtkWidget       *object,
                                        gpointer         user_data);

void
on_Return_gAgents_Admin_clicked        (GtkWidget *  objet_graphique,
                                        gpointer         user_data);

void
on_button_Add_Agent_clicked            (GtkWidget *  objet_graphique,
                                        gpointer         user_data);

void
on_button_Save_Agent_clicked           (GtkWidget *  objet_graphique,
                                        gpointer         user_data);

void
on_treeview_Agents_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Dell_Agent_clicked                  (GtkWidget *  objet_graphique,
                                        gpointer         user_data);


void
on_Disconect_Admin_Interface_clicked   (GtkWidget *  objet_graphique,
                                        gpointer         user_data);


void
on_Consulter_Catalogues_clicked        (GtkButton       *button,
                                        gpointer         user_data);





void
on_buttonEdit_User_clicked             (GtkWidget *objet_graphique,
                                        gpointer         user_data);

void
on_buttonDelete_User_clicked           (GtkWidget *  objet_graphique,
                                        gpointer         user_data);



void
on_Return_toAgents_Gesture_clicked     (GtkWidget *  objet_graphique,
                                        gpointer         user_data);

void
on_buttonSearch_Users_Gesture_clicked  (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_treeview_Users_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_Prest_Gesture_clicked        (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_buttonSearch_Catalogue_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_filechooser_selection_changed       (GtkFileChooser  *filechooser,
					gpointer         user_data);

void                                        
on_Edit_Catalogues_clicked(GtkWidget     *objet_graphique,
                                        gpointer         user_data);
void
on_Delete_Catalogues_clicked(GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_okbutton_Email_Error_clicked        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_Sace_Edit_Agent_clicked      (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_button_Agent_Editer_clicked         (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_gestion_hotel_clicked               (GtkWidget *  objet_graphique,
                                        gpointer         user_data);

void
on_gestion_voitures_clicked            (GtkWidget *  objet_graphique,
                                        gpointer         user_data);

void
on_Gestion__vols_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_Gestion__excursions_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_Retour_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_to_gest_prestation_clicked   (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_recherche_hotel_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ajout_hotel_clicked                 (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_Modifier_hotel_clicked              (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_supprimer_hotel_clicked             (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_recherche_voiture_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajout_voiture_clicked               (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_modifier_voiture_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_voiture_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_Valider_hotel_clicked               (GtkWidget *objet_graphique,
                                        gpointer         user_data);

void
on_return_ajout_to_gest_hotel_clicked  (GtkWidget *objet_graphique,
                                        gpointer         user_data);

void
on_return_ajout_hotel_to_gest_hotel_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider_voiture_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider_modif_hotel_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_return_modif_hotel_to_gest_hotel_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_valider_amodif_voiture_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_return_modif_voiture_to_gest_voiture_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);


void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_return_gest_voiture_to_gest_prest_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);







void
on_treeview_Hotel_Gestion_Hotel_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_Save_Edit_User_clicked       (GtkWidget *objet_graphique,
                                        gpointer         user_data);



void
on_button_add_catala_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_add_catala_hotel_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_Add_Catalogue_Gesture_clicked
                                        (GtkWidget *objet_graphique,
                                        gpointer         user_data);

void
on_Valider_modif_clicked               (GtkButton       *button,
                                        gpointer         user_data);
