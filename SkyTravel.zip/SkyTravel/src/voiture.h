
struct Voiture
{
char Marque[20];
char Lieu[20];
char Date [20] ;
char Matricule[20];
char Prix[20];
char Tel[20];

};
typedef struct Voiture Voiture;
Voiture get_voiture_info(GtkWidget *objet_graphique);
void save_voiture(Voiture v);
void afficher_voiture(GtkWidget *liste);
void supp_voiture(Voiture Selected_voiture);


