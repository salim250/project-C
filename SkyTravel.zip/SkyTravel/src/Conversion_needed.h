
int no_of_digits(int num);



char *i_to_a(int num);
