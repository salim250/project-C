#include<stdlib.h>
#include<stdio.h>
#include <gtk/gtk.h>
#include <string.h>
#include"Admin.h"
#include"Users.h"
#include "support.h"
#include "callbacks.h"

enum
{	
	c_PSEUDO,
	c_NOM,
	c_PRENOM,
	c_EMAIL,
	c_ADRESSE,
	c_TEL,
	c_COLUMNS
};
/********************Afficher all Agents ************************/
void afficher_Agents(GtkWidget *liste)
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

  store=gtk_tree_view_get_model(liste);
  if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Pseudo", renderer, "text",c_PSEUDO, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Nom", renderer, "text",c_NOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Prenom", renderer, "text",c_PRENOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Email", renderer, "text",c_EMAIL, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Telephone", renderer, "text",c_TEL, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	


	
	}
	store=gtk_list_store_new (c_COLUMNS, G_TYPE_STRING,  		G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, 		G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

struct User X;
FILE *f;
/******************************************************/
f=fopen("/home/bouzayen/Desktop/Skytravel/Users.bin","rb");
int i=0;
while(!(feof(f)))
{
fread(&X,1,sizeof(X),f);
i++;
}
fclose(f);
g_print("\n i = %d",i);
/**********************************************************/
f=fopen("/home/bouzayen/Desktop/Skytravel/Users.bin","rb");
if(f!=NULL)
	{
	int j=0;
	while(j<i-1)
		{
		fread(&X,1,sizeof(X),f);
		if(!(strcmp(X.Type,"Agent")))
		{gtk_list_store_append (store, &iter);
		gtk_list_store_set (store, &iter, c_PSEUDO, X.Pseudo, c_NOM, X.nom, c_PRENOM, X.prenom, c_EMAIL, X.Email,c_ADRESSE,X.Adresse,c_TEL,X.Tel, -1);}

 j++;
		}
	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
        g_object_unref (store);
	}

}

/********************Afficher just searched Agent ************************/
void afficher_Searched_Agents(GtkWidget *liste ,char *searh_Pseudo,char *searh_Prenom,char*searh_Nom,char*searh_Email,char*searh_Tel)
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;
	
  store=gtk_tree_view_get_model(liste);

  if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Pseudo", renderer, "text",c_PSEUDO, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Nom", renderer, "text",c_NOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Prenom", renderer, "text",c_PRENOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Email", renderer, "text",c_EMAIL, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Telephone", renderer, "text",c_TEL, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	


	
	}//if(store==NULL)
        
	store=gtk_list_store_new (c_COLUMNS, G_TYPE_STRING,  		G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, 		G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

struct User X;
FILE *f;
/******************************************************/
f=fopen("/home/bouzayen/Desktop/Skytravel/Users.bin","rb");
int i=0;
while(!(feof(f)))
{
fread(&X,1,sizeof(X),f);
i++;
}
fclose(f);

/**********************************************************/

int j=0;
if(!(strcmp(searh_Pseudo,""))&&!(strcmp(searh_Prenom,""))&&!(strcmp(searh_Nom,""))&&!(strcmp(searh_Email,""))&&!(strcmp(searh_Tel,"")))
{
f=fopen("/home/bouzayen/Desktop/Skytravel/Users.bin","rb");
if(f!=NULL)
	{
	j=0;
	while(j<i-1)
		{
		g_print("\n J =%d",j);
		fread(&X,1,sizeof(X),f);
		if(!(strcmp(X.Type,"Agent")))
		{gtk_list_store_append (store, &iter);
		gtk_list_store_set (store, &iter, c_PSEUDO, X.Pseudo, c_NOM, X.nom, c_PRENOM, X.prenom, c_EMAIL, X.Email,c_ADRESSE,X.Adresse,c_TEL,X.Tel, -1); 
		}//if(!(strcmp(X.Type,"Agent")))
		j++;
		}//while(j<i-1)
	
	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
        g_object_unref (store);
	}//if(f!=NULL)
}//if loula
else
{//*searh_Pseudo,*searh_Prenom,*searh_Nom,*searh_Email,*searh_Tel;

	f=fopen("/home/bouzayen/Desktop/Skytravel/Users.bin","rb");
if(f!=NULL)
	{
	j=0;
	while(j<i-1)
		{	g_print("\n J =%d",j);
		fread(&X,1,sizeof(X),f);
		if(!(strcmp(X.Type,"Agent")))
		{if(!(strcmp(X.Pseudo,searh_Pseudo))||!(strcmp(X.prenom,searh_Prenom))||!(strcmp(X.nom,searh_Nom))||!(strcmp(X.Email,searh_Email))||!(strcmp(X.Tel,searh_Tel)))
		{
		gtk_list_store_append (store, &iter);
		gtk_list_store_set (store, &iter, c_PSEUDO, X.Pseudo, c_NOM, X.nom, c_PRENOM, X.prenom, c_EMAIL, X.Email,c_ADRESSE,X.Adresse,c_TEL,X.Tel, -1);
		}}//if serach
		 j++;
		}//while(j<i-1)
	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
        g_object_unref (store);
}//if(f!=NULL)
	}//else
}//void 
