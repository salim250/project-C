#include<stdlib.h>
#include<stdio.h>
#include <gtk/gtk.h>
#include <string.h>
#include "support.h"
#include "callbacks.h"

struct date
{
int jour;
int mois;
int anne;

};
typedef struct date date;
struct Catalogue_Hotel
{  char Image_path[500];
   char Title[100];
	struct date date_debut ;
	struct date date_fin ;
	char Nom[50];
char Lieu[50];
int Prix_ch_simple_1pers;
int Prix_ch_double_1pers;
int Prix_ch_double_2pers;
int Prix_ch_Triple_1pers;
int Prix_ch_Triple_2pers;
int Prix_ch_Triple_3pers;
int Prix_sweat_1pers;
int Prix_sweat_2pers;
int Prix_sweat_3pers;
char Categorie[50];
char Tel[20];
   char Description[5000];
int reduction;
   
};
typedef struct Catalogue_Hotel Catalogue_Hotel;
void afficher_catalogue_Gesture(GtkWidget *viewport_Catalogue,GtkWidget     *Catalogue_Gesture_interface);
void call();
void supp_catalogue_Hotel(char *nom_cat);
Catalogue_Hotel Get_Catalogue_info(GtkWidget       *objet_graphique);
void Save_Catalogue_Hotel(Catalogue_Hotel H);
