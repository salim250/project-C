#include"Conversion_needed.h"
#include <gtk/gtk.h>
#include"Catalogues.h"
#include "interface.h"
#include "support.h"
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"Users.h"
#include"Verif_login.h"
#include"Conversion_needed.h"
#include"Admin.h"

enum
{	
	c_Image_path,
	c_Title,
	c_PRENOM,
	c_Description,
	c_PRIX,
	c_COLUMNS
};
void afficher_catalogue_Gesture(GtkWidget *viewport_Catalogue,GtkWidget     *Catalogue_Gesture_interface)
{
GtkWidget *Table_show_Catalogues ;
struct Catalogue_Hotel Catalogues[200];
int nb_cat=0,i,j;
FILE *f;
f=fopen("/home/bouzayen/Desktop/Skytravel/Catalogue.bin","rb");
if(f!=NULL)
{	nb_cat=0;
		while(!(feof(f)))
		{nb_cat++;
	fread(&Catalogues[nb_cat],1,sizeof(Catalogues[nb_cat]),f);
				
		}
	fclose(f);
}
g_print("Nb de Catlo %d",nb_cat);

 Table_show_Catalogues = gtk_table_new (nb_cat-1, 7, FALSE);
  gtk_widget_show (Table_show_Catalogues);
  gtk_container_add (GTK_CONTAINER (viewport_Catalogue), Table_show_Catalogues);

f=fopen("/home/bouzayen/Desktop/Skytravel/Catalogue.bin","rb");
if(f!=NULL)
{
i=1;
GtkWidget *Labels_catalogue[200][7];
GtkWidget *image[200],*button[200],*button_supp[200];
char *buffer;
const GdkPixbuf *pb ;char date[100];
g_print("\nGetting in while %d",i);
while(i<nb_cat)
	{
g_print("\n In While iti : %d",i);
fread(&Catalogues,1,sizeof(Catalogues[i]),f);;
   /*****Image*******/
	j=0;
  image[i] = create_pixmap (Catalogue_Gesture_interface,Catalogues[i].Image_path );
  gtk_widget_show (image[i]);
GdkPixbuf *pb = gtk_image_get_pixbuf(GTK_IMAGE(image[i] ));
 //gdk_pixbuf_get_width(pb)/gdk_pixbuf_get_height(pb));
  gtk_table_attach (GTK_TABLE (Table_show_Catalogues), image[i], j, j+1, i, i+1,(GtkAttachOptions) (GTK_EXPAND | GTK_FILL),(GtkAttachOptions) (GTK_EXPAND), 0, 0);
//Sizeing image
  gtk_widget_set_size_request (image[i], gdk_pixbuf_get_width(pb), gdk_pixbuf_get_height(pb));
   /*****Tille*******/
	j=1;
Labels_catalogue[i][j]=gtk_label_new (Catalogues[i].Title);
	gtk_widget_show (Labels_catalogue[i][j]);
  	gtk_table_attach (GTK_TABLE (Table_show_Catalogues), Labels_catalogue[i][j], j, j+1, i, i+1,(GtkAttachOptions) (GTK_EXPAND | GTK_FILL),(GtkAttachOptions) (GTK_EXPAND), 0, 0);
   /*****Date de Début*******/
	j=3;
strcpy(date,"Du ");
buffer=i_to_a((Catalogues[i].date_debut.jour));
strcat(date,buffer);
strcat(date,"/");
buffer=i_to_a((Catalogues[i].date_debut.mois));
strcat(date,buffer);
strcat(date,"/");
buffer=i_to_a((Catalogues[i].date_debut.anne));
strcat(date,buffer);
Labels_catalogue[i][j]=gtk_label_new (date);
	gtk_widget_show (Labels_catalogue[i][j]);
  	gtk_table_attach (GTK_TABLE (Table_show_Catalogues), Labels_catalogue[i][j], j, j+1, i, i+1,(GtkAttachOptions) (GTK_EXPAND | GTK_FILL),(GtkAttachOptions) (GTK_EXPAND), 0, 0);
   /*****Date de fin*******/
	j=4;
strcpy(date,"Au ");
buffer=i_to_a((Catalogues[i].date_fin.jour));
strcat(date,buffer);
strcat(date,"/");
buffer=i_to_a((Catalogues[i].date_fin.mois));
strcat(date,buffer);
strcat(date,"/");
buffer=i_to_a((Catalogues[i].date_fin.anne));
strcat(date,buffer);
Labels_catalogue[i][j]=gtk_label_new (date);
	gtk_widget_show (Labels_catalogue[i][j]);
  	gtk_table_attach (GTK_TABLE (Table_show_Catalogues), Labels_catalogue[i][j], j, j+1, i, i+1,(GtkAttachOptions) (GTK_EXPAND | GTK_FILL),(GtkAttachOptions) (GTK_EXPAND), 0, 0);


   /*****Descreption*******/
	j=5;
Labels_catalogue[i][j]=gtk_label_new (Catalogues[i].Description);
	gtk_widget_show (Labels_catalogue[i][j]);
  	gtk_table_attach (GTK_TABLE (Table_show_Catalogues), Labels_catalogue[i][j], j, j+1, i, i+1,(GtkAttachOptions) (GTK_EXPAND | GTK_FILL),(GtkAttachOptions) (GTK_EXPAND), 0, 0);
gtk_widget_set_size_request (Labels_catalogue[i][j],250,75);
   /*****Prix*******/
	j=2;
buffer= i_to_a((Catalogues[i].Prix_ch_simple_1pers));
strcat(buffer," Dt");
Labels_catalogue[i][j]=gtk_label_new (buffer);
	gtk_widget_show (Labels_catalogue[i][j]);
  	gtk_table_attach (GTK_TABLE (Table_show_Catalogues), Labels_catalogue[i][j], j, j+1, i, i+1,(GtkAttachOptions) (GTK_EXPAND | GTK_FILL),(GtkAttachOptions) (GTK_EXPAND), 0, 0);

//g_print("Le prix de %d est = %d",i,Catalogues[i].Prix_ch_simple_1pers);
/*****Bouton Supp w Modif*******/
	j=6;
button[i]=gtk_button_new_with_mnemonic (_("Modifier"));
gtk_widget_show (button[i]);
gtk_table_attach (GTK_TABLE (Table_show_Catalogues), button[i], j, j+1, i, i+1,(GtkAttachOptions) (GTK_EXPAND | GTK_FILL),(GtkAttachOptions) (GTK_EXPAND), 0, 0);

  g_signal_connect ((gpointer) button[i], "clicked",
                    G_CALLBACK (on_Edit_Catalogues_clicked),
                    Catalogues[i].Title);

j=7;
button_supp[i]=gtk_button_new_with_mnemonic (_("Supprimer"));
gtk_widget_show (button_supp[i]);
gtk_table_attach (GTK_TABLE (Table_show_Catalogues), button_supp[i], j, j+1, i, i+1,(GtkAttachOptions) (GTK_EXPAND | GTK_FILL),(GtkAttachOptions) (GTK_EXPAND), 0, 0);

  g_signal_connect ((gpointer) button_supp[i], "clicked",
                    G_CALLBACK (on_Delete_Catalogues_clicked),
                    Catalogues[i].Title);
;
i++;

		}//while
}//if

  gtk_widget_show (viewport_Catalogue);


}/****************************************************/
Catalogue_Hotel Get_Catalogue_info(GtkWidget       *objet_graphique)
{Catalogue_Hotel c;
strcpy(c.Image_path,"sky-travel-logo.png");
GtkWidget *input;
input=lookup_widget(objet_graphique,"comboboxentrycateg_cata");
strcpy(c.Categorie,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input)));

input=lookup_widget(objet_graphique,"entry_nom_catalogue");
strcpy(c.Title,gtk_entry_get_text(GTK_ENTRY(input))); 

input=lookup_widget(objet_graphique,"entry_reduction");
c.reduction=gtk_spin_button_get_value_as_int(GTK_ENTRY(input));

input=lookup_widget(objet_graphique,"Add_cat_jour_debut");
c.date_debut.jour=gtk_spin_button_get_value_as_int(GTK_ENTRY(input));

input=lookup_widget(objet_graphique,"Add_cat_mois_debut");
c.date_debut.mois=gtk_spin_button_get_value_as_int(GTK_ENTRY(input));

input=lookup_widget(objet_graphique,"Add_cat_anne_debut");
c.date_debut.anne=gtk_spin_button_get_value_as_int(GTK_ENTRY(input));

input=lookup_widget(objet_graphique,"Add_cat_jour_fin");
c.date_fin.jour=gtk_spin_button_get_value_as_int(GTK_ENTRY(input));

input=lookup_widget(objet_graphique,"Add_cat_mois_fin");
c.date_fin.mois=gtk_spin_button_get_value_as_int(GTK_ENTRY(input));

input=lookup_widget(objet_graphique,"Add_cat_anne_fin");
c.date_fin.anne=gtk_spin_button_get_value_as_int(GTK_ENTRY(input));
return c;
}
/****************************************************/
void Save_Catalogue_Hotel(Catalogue_Hotel H)
{

FILE *f;
f=fopen("/home/bouzayen/Desktop/Skytravel/Catalogue.bin","ab+");
if(f!=NULL)
	{
	fwrite(&H,sizeof(H),1,f);
	}

}
void supp_catalogue_Hotel(char *nom_cat)
{

struct Catalogue_Hotel H;
FILE *f;
FILE *d;
f=fopen("/home/bouzayen/Desktop/Skytravel/Catalogue.bin","rb");
d=fopen("/home/bouzayen/Desktop/Skytravel/Cataloguetmp.bin","wb");
fclose(d);
d=fopen("/home/bouzayen/Desktop/Skytravel/Cataloguetmp.bin","ab");
if(f!=NULL);
{
while(!(feof(f)))	

	{
	fread(&H,1,sizeof(Catalogue_Hotel),f);
	if((strcmp(H.Title,nom_cat)!=0))
	{g_print("\ncopied %s\n",H.Title);
	fwrite(&H,sizeof(Catalogue_Hotel),1,d);
	}
	}
fclose(d);
fclose(f);
remove("/home/bouzayen/Desktop/Skytravel/Catalogue.bin");
rename("/home/bouzayen/Desktop/Skytravel/Cataloguetmp.bin","/home/bouzayen/Desktop/Skytravel/Catalogue.bin");
}}
